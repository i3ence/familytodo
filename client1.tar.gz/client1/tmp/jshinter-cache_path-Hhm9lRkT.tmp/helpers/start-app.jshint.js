describe('JSHint - helpers/start-app.js', function(){
it('should pass jshint', function() { 
  expect(true, 'helpers/start-app.js should pass jshint.').to.be.ok; 
})});
