describe('JSHint - test-helper.js', function(){
it('should pass jshint', function() { 
  expect(true, 'test-helper.js should pass jshint.').to.be.ok; 
})});
