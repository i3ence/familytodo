describe('JSHint - app.js', function(){
it('should pass jshint', function() { 
  expect(true, 'app.js should pass jshint.').to.be.ok; 
})});
