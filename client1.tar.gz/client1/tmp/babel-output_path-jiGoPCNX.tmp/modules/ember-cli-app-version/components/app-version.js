import Ember from 'ember';
import layout from '../templates/app-version';

export default Ember.Component.extend({
  tagName: 'span',
  layout: layout
});