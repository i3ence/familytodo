QUnit.module('JSHint - helpers');
QUnit.test('helpers/start-app.js should pass jshint', function(assert) { 
  assert.ok(true, 'helpers/start-app.js should pass jshint.'); 
});
